<script>
export default {
  name: 'App' 
};
</script>

<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style>
/* 添加全局样式 */
</style>
