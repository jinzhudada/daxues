import { createRouter, createWebHistory } from 'vue-router';
import Login from './components/Login.vue';
import Register from './components/Register.vue';
import Upload from './components/Upload.vue';
import PopularResources from './components/PopularResources.vue';

const routes = [
  { path: '/', component: Login },
  { path: '/register', component: Register },
  { path: '/upload', component: Upload },
  { path: '/popular', component: PopularResources }
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;
