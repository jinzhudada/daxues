<template>
  <div>
    <h2>上传资源</h2>
    <form @submit.prevent="uploadResource">
      <input v-model="title" placeholder="资源标题" required />
      <input type="file" @change="handleFileUpload" required />
      <button type="submit" :disabled="loading">上传</button>
      <div v-if="loading">上传中...</div>
    </form>
  </div>
</template>

<script>
import axios from 'axios';
import { useUserStore } from '../stores/userStore'; // 引入用户存储

export default {
  data() {
    return {
      title: '',
      file: null,
      loading: false // 添加加载状态
    };
  },
  methods: {
    handleFileUpload(event) {
      this.file = event.target.files[0];
    },
    async uploadResource() {
      const formData = new FormData();
      formData.append('title', this.title);
      formData.append('file', this.file);

      this.loading = true; // 开始加载

      try {
        const userStore = useUserStore();
        if (!userStore.isLoggedIn) {
          alert('请先登录！');
          return;
        }

        const response = await axios.post('http://127.0.0.1:8000/api/users/upload/', formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        });
        alert('上传成功！');
      } catch (error) {
        alert('上传失败: ' + error.response.data.error);
      } finally {
        this.loading = false; // 数据加载完成
      }
    }
  }
};
</script>

<style scoped>
/* 添加样式 */
</style>
