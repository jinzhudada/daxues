<template>
  <div>
    <h2>用户注册</h2>
    <form @submit.prevent="register">
      <input v-model="username" placeholder="用户名" required />
      <input v-model="email" type="email" placeholder="邮箱" required />
      <input v-model="password" type="password" placeholder="密码" required />
      <input v-model="studentId" placeholder="学号" required />
      <button type="submit">注册</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';
import { useUserStore } from '../stores/userStore'; // 引入用户存储

export default {
  data() {
    return {
      username: '',
      email: '',
      password: '',
      studentId: ''
    };
  },
  methods: {
    async register() {
      try {
        const response = await axios.post('http://127.0.0.1:8000/api/users/register/', {
          username: this.username,
          email: this.email,
          password: this.password,
          student_id: this.studentId
        });
        alert('注册成功！');
      } catch (error) {
        alert(error.response.data.error);
      }
    }
  }
};
</script>

<style scoped>
/* 添加样式 */
</style>
