<template>
  <div>
    <h2>用户登录</h2>
    <form @submit.prevent="login">
      <input v-model="username" placeholder="用户名" required />
      <input v-model="password" type="password" placeholder="密码" required />
      <button type="submit">登录</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';
import { useUserStore } from '../stores/userStore'; // 引入用户存储

export default {
  data() {
    return {
      username: '',
      password: ''
    };
  },
  methods: {
    async login() {
      try {
        const response = await axios.post('http://127.0.0.1:8000/api/users/login/', {
          username: this.username,
          password: this.password
        });
        const userStore = useUserStore();
        userStore.login(response.data.user); // 更新用户状态
        alert(response.data.message);
      } catch (error) {
        alert(error.response.data.error);
      }
    }
  }
};
</script>

<style scoped>
/* 添加样式 */
</style>
