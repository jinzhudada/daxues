<template>
  <div>
    <h2>热门资源</h2>
    <div v-if="loading">加载中...</div>
    <ul v-else>
      <li v-for="resource in resources" :key="resource.id">
        {{ resource.title }} - 下载次数: {{ resource.download_count }}
        <Comments :resourceId="resource.id" />
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios';
import { useUserStore } from '../stores/userStore'; // 引入用户存储
import Comments from './Comments.vue'; // 引入评论组件

export default {
  components: {
    Comments
  },
  data() {
    return {
      resources: [],
      loading: true // 添加加载状态
    };
  },
  async created() {
    await this.fetchPopularResources();
  },
  methods: {
    async fetchPopularResources() {
      try {
        const response = await axios.get('http://127.0.0.1:8000/api/users/popular/');
        this.resources = response.data;
      } catch (error) {
        console.error("获取热门资源失败:", error);
      } finally {
        this.loading = false; // 数据加载完成
      }
    }
  }
};
</script>

<style scoped>
/* 添加样式 */
</style>
