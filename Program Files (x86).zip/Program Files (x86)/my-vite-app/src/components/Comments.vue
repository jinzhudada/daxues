<template>
  <div>
    <h3>评论</h3>
    <form @submit.prevent="addComment">
      <input v-model="newComment" placeholder="添加评论" required />
      <button type="submit">提交</button>
    </form>
    <ul>
      <li v-for="comment in comments" :key="comment.id">{{ comment.text }}</li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  props: {
    resourceId: {
      type: Number,
      required: true
    }
  },
  data() {
    return {
      comments: [],
      newComment: ''
    };
  },
  async created() {
    await this.fetchComments();
  },
  methods: {
    async fetchComments() {
      try {
        const response = await axios.get(`http://127.0.0.1:8000/api/comments/${this.resourceId}/`);
        this.comments = response.data;
      } catch (error) {
        console.error("获取评论失败:", error);
      }
    },
    async addComment() {
      try {
        const response = await axios.post(`http://127.0.0.1:8000/api/comments/${this.resourceId}/`, {
          text: this.newComment
        });
        this.comments.push(response.data);
        this.newComment = ''; // 清空输入框
      } catch (error) {
        console.error("添加评论失败:", error);
      }
    }
  }
};
</script>

<style scoped>
/* 添加样式 */
</style>
