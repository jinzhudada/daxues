# -*- coding: utf-8 -*-

'''
第3关：利用pandas实现数据统计分析
'''
import numpy as np
import pandas as pd

master = pd.read_csv("Training_Master.csv",encoding='gbk')
user = pd.read_csv("Training_Userupdate.csv",encoding='gbk')
log = pd.read_csv("Training_LogInfo.csv",encoding='gbk')

# 3.1用户来源地评价。
#    在master表中用value_counts方法实现按用户所在地（UserInfo_2）统计用户数，
#    并按照如下格式输出统计结果的前5项（其中为英文符号）
#    城市:(用户数)
############begin############
locations_and_counts = master["UserInfo_2"].value_counts()
for location,count in location_and_counts.head(5).items():
    print(location+":"+"(%d)"%count)
#############end#############

#3.2 未登录用户分析。
#    结合master表和log表的内容，
#    求取从未登录的用户的数量，直接输出
############begin############
logUsers = set(log["Idx"])
allUsers = set(master["Idx"])
notLogUsers = alUsers-logUsers
print(len(notLogUsers))
#############end#############

#3.3 用户活跃度分析。
#    求取信息更新（user表）次数最多的用户的最早登录时间（LogInfo3）
#    输出用户Idx，更新次数，最早登录时间
############begin############
maxLogUser = user.groupby("Idx").size().idxmax()
maxUpdateCounts = user.groupby("Idx").size().max()
earlistLogTime = log.loc[log["Idx"]==maxLogUser]["LogInfo3"].min()
print(str(maxLogUser)+" "+str(maxUpdateCounts)+" "str(earlistLogTime))
print(str(maxLogUser) + " " + str(maxUpdateCounts) + " " + str(earlistLogTime))
#############end#############

# 3.4 用户活跃期分析。
#     给user表增加新列“weekday”，填入更新日期（UserupdateInfo2）相应的星期名称
#     用groupby和nunique方式实现
#     按星期名称统计用户更新人数（注意，是人数），并输出
############begin############
user["UserupdateInfo2"] = pd.to_datetime(user["UserupdateInfo2"])
user["weekday"] = user["UserupdateInfo2"].dt.day_name()
result = user.groupby("weekday")['Idx'].nunique()
print(result)
#############end#############