from django.shortcuts import render
from rest_framework import generics, viewsets
from .models import User, Resource, Comment
from .serializers import UserSerializer, ResourceSerializer, CommentSerializer
from rest_framework.permissions import BasePermission, IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth import authenticate
from rest_framework.views import APIView
from django.http import FileResponse

# Create your views here.

class UserRegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer

class IsTeacher(BasePermission):
    def has_permission(self, request, view):
        return request.user.role == 'teacher'

class IsAdmin(BasePermission):
    def has_permission(self, request, view):
        return request.user.role == 'admin'

class ResourceDownloadView(generics.RetrieveAPIView):
    queryset = Resource.objects.all()
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        resource = self.get_object()
        if not resource.is_approved:
            return Response({"error": "资源未审核通过"}, status=status.HTTP_403_FORBIDDEN)
        
        resource.download_count += 1
        resource.save()
        response = FileResponse(open(resource.file.path, 'rb'))
        return response

class UserLoginView(APIView):
    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            user.login_count += 1  # 增加登录次数
            user.save()
            return Response({"message": "登录成功", "role": user.role})
        return Response({"error": "用户名或密码错误"}, status=status.HTTP_401_UNAUTHORIZED)

class ResourceUploadView(generics.CreateAPIView):
    queryset = Resource.objects.all()
    serializer_class = ResourceSerializer
    permission_classes = [IsAuthenticated]  # 只有登录用户可以上传资源

    def perform_create(self, serializer):
        serializer.save(uploader=self.request.user)  # 保存上传者信息

class ResourceApprovalView(APIView):
    permission_classes = [IsAuthenticated, IsTeacher]  # 只有教师可以审核

    def post(self, request, resource_id):
        try:
            resource = Resource.objects.get(id=resource_id)
            resource.is_approved = True  # 设置为已审核
            resource.save()
            return Response({"message": "资源审核通过"}, status=status.HTTP_200_OK)
        except Resource.DoesNotExist:
            return Response({"error": "资源未找到"}, status=status.HTTP_404_NOT_FOUND)

class PopularResourcesView(generics.ListAPIView):
    queryset = Resource.objects.all().order_by('-download_count')[:10]  # 获取下载次数最多的前10个资源
    serializer_class = ResourceSerializer
    permission_classes = [IsAuthenticated]  # 只有登录用户可以查看

class CommentViewSet(viewsets.ModelViewSet):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer

    def get_queryset(self):
        resource_id = self.kwargs['resource_id']
        return self.queryset.filter(resource_id=resource_id)
