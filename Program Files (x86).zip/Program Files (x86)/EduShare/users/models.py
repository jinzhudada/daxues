from django.contrib.auth.models import AbstractUser
from django.db import models

# Create your models here.

class User(AbstractUser):
    ROLE_CHOICES = [
        ('student', '学生'),
        ('teacher', '教师'),
        ('admin', '管理员'),
    ]
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='student')
    student_id = models.CharField(max_length=20, unique=True)  # 学号
    login_count = models.IntegerField(default=0)  # 新增登录次数字段

class Resource(models.Model):
    title = models.CharField(max_length=255)
    file = models.FileField(upload_to='resources/')
    upload_time = models.DateTimeField(auto_now_add=True)
    download_count = models.IntegerField(default=0)
    uploader = models.ForeignKey('User', on_delete=models.CASCADE, null=True)  # 允许为 null
    is_approved = models.BooleanField(default=False)  # 新增审核状态字段

    def __str__(self):
        return self.title

class Comment(models.Model):
    resource = models.ForeignKey(Resource, on_delete=models.CASCADE)  # 关联资源
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.text
