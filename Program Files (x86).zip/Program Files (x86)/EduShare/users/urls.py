from django.urls import path
from .views import UserRegisterView, UserLoginView, ResourceUploadView, ResourceApprovalView, ResourceDownloadView, PopularResourcesView, CommentViewSet
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register(r'comments/(?P<resource_id>[^/.]+)', CommentViewSet, basename='comments')

urlpatterns = [
    path('register/', UserRegisterView.as_view(), name='user-register'),
    path('login/', UserLoginView.as_view(), name='user-login'),
    path('upload/', ResourceUploadView.as_view(), name='resource-upload'),
    path('approve/<int:resource_id>/', ResourceApprovalView.as_view(), name='resource-approve'),
    path('download/<int:pk>/', ResourceDownloadView.as_view(), name='resource-download'),
    path('popular/', PopularResourcesView.as_view(), name='popular-resources'),
]

urlpatterns += router.urls  # 添加评论路由
