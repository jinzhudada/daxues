from django.http import HttpResponse

def home(request):
    return HttpResponse("欢迎来到 EduShare 学习资源共享平台！")
